import time
from fastapi.testclient import TestClient
from backend.src.api.main import app


def test_ingest_pipeline_completed():
    client = TestClient(app)
    files = {"file": ("sample_pipeline.txt", b"one\ntwo\nthree")}
    r = client.post("/upload", files=files)
    assert r.status_code == 200
    task_id = r.json().get("task_id")
    assert task_id

    # poll until ready or timeout (5s for tests)
    end = time.time() + 5
    status = None
    while time.time() < end:
        r2 = client.get(f"/ingest/{task_id}")
        assert r2.status_code in (200, 404)
        if r2.status_code == 200:
            status = r2.json().get("status")
            if status in ("ready", "error"):
                break
        time.sleep(0.2)

    assert status == "ready"
