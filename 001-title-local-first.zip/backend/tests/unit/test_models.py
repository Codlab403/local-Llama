from backend.src.models.document import Document
from backend.src.models.node import Node


def test_document_model():
    d = Document(id="d1", filename="f.txt", uploaded_at=None)
    assert d.id == "d1"


def test_node_model():
    n = Node(id="n1", doc_id="d1", snippet="hello")
    assert n.doc_id == "d1"
