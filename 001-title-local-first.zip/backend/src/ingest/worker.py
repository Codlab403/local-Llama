from ..db import meta
from ..embeddings import adapter
from ..storage import fs_store
from ..vectorstore import get_default_store
import uuid


def _chunk_text(text: str, chunk_size: int = 200, overlap: int = 50):
    chunks = []
    i = 0
    while i < len(text):
        chunk = text[i : i + chunk_size]
        chunks.append(chunk)
        i += chunk_size - overlap
    return chunks


def process_task(task_id: str):
    task = meta.get_task(task_id)
    if not task:
        return
    meta.update_task_status(task_id, "indexing")
    upload_path = task.get("upload_path")
    if not upload_path:
        # fallback: try to find the file in the default uploads directory by filename
        filename = task.get("filename")
        if not filename:
            meta.update_task_status(task_id, "error")
            return
        try:
            candidate = fs_store.BASE_UPLOAD_DIR / filename
            if not candidate.exists():
                meta.update_task_status(task_id, "error")
                return
            upload_path = str(candidate)
        except Exception:
            meta.update_task_status(task_id, "error")
            return

    try:
        with open(upload_path, "r", encoding="utf-8", errors="ignore") as f:
            text = f.read()
    except Exception:
        meta.update_task_status(task_id, "error")
        return

    chunks = _chunk_text(text)
    store = get_default_store()
    for idx, chunk in enumerate(chunks, start=1):
        emb = adapter.embed_text(chunk)
        node_id = f"{task_id}-{idx}"
        metadata = {"doc_id": task_id, "page": idx, "snippet": chunk[:200]}
        store.add(node_id, emb, metadata)

    meta.update_task_status(task_id, "ready")
