from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.responses import JSONResponse
from ..db import meta
from ..storage import fs_store
from ..ingest import worker
from ..chat import handler
import uvicorn
from contextlib import asynccontextmanager


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Initialize DB and other startup tasks here
    meta.init_db()
    yield
    # Place for graceful shutdown tasks if needed


app = FastAPI(lifespan=lifespan)


@app.post("/upload")
async def upload(file: UploadFile = File(...)):
    content = await file.read()
    path = fs_store.save_upload(file.filename, content)
    task_id = meta.create_task(file.filename, upload_path=path)
    # For dev convenience, process synchronously
    worker.process_task(task_id)
    return JSONResponse({"task_id": task_id})


@app.get("/ingest/{task_id}")
def ingest_status(task_id: str):
    t = meta.get_task(task_id)
    if not t:
        raise HTTPException(status_code=404, detail="task not found")
    return JSONResponse(t)


@app.post("/chat")
def chat(payload: dict):
    session_id = payload.get("session_id")
    query = payload.get("query")
    top_k = payload.get("top_k", 3)
    result = handler.orchestrate_query(session_id or "", query or "", top_k)
    return JSONResponse(result)


if __name__ == "__main__":
    uvicorn.run("backend.src.api.main:app", host="0.0.0.0", port=8000, reload=True)
