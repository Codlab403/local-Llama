import sqlite3
from pathlib import Path
import uuid

DB_PATH = Path("C:/Users/Tcyber/Documents/PROJECTS/LlamaInde-Chatbot/data/metadata.db")


def get_conn():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(DB_PATH))
    return conn


def init_db():
    conn = get_conn()
    cur = conn.cursor()
    cur.execute(
        """
    CREATE TABLE IF NOT EXISTS ingest_tasks (
        task_id TEXT PRIMARY KEY,
        filename TEXT,
        upload_path TEXT,
        status TEXT,
        created_at TEXT
    )
    """
    )
    # Ensure migration: if the column `upload_path` is missing on an older DB, add it.
    try:
        cur.execute("PRAGMA table_info('ingest_tasks')")
        cols = [r[1] for r in cur.fetchall()]
        if "upload_path" not in cols:
            cur.execute("ALTER TABLE ingest_tasks ADD COLUMN upload_path TEXT")
    except Exception:
        # best-effort migration; ignore failures to avoid blocking startup in tests
        pass
    conn.commit()
    conn.close()


def create_task(filename: str, upload_path: str | None = None) -> str:
    task_id = str(uuid.uuid4())
    conn = get_conn()
    cur = conn.cursor()
    try:
        cur.execute(
            "INSERT INTO ingest_tasks (task_id, filename, upload_path, status, created_at) VALUES (?, ?, ?, ?, datetime('now'))",
            (task_id, filename, upload_path, "queued"),
        )
    except sqlite3.OperationalError:
        # older schema without upload_path; fall back to original insert
        cur.execute(
            "INSERT INTO ingest_tasks (task_id, filename, status, created_at) VALUES (?, ?, ?, datetime('now'))",
            (task_id, filename, "queued"),
        )
    conn.commit()
    conn.close()
    return task_id


def update_task_status(task_id: str, status: str) -> None:
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("UPDATE ingest_tasks SET status = ? WHERE task_id = ?", (status, task_id))
    conn.commit()
    conn.close()


def get_task(task_id: str):
    conn = get_conn()
    cur = conn.cursor()
    try:
        cur.execute(
            "SELECT task_id, filename, upload_path, status, created_at FROM ingest_tasks WHERE task_id = ?",
            (task_id,),
        )
        row = cur.fetchone()
        conn.close()
        if not row:
            return None
        return {"task_id": row[0], "filename": row[1], "upload_path": row[2], "status": row[3], "created_at": row[4]}
    except sqlite3.OperationalError:
        # older schema without upload_path
        cur.execute("SELECT task_id, filename, status, created_at FROM ingest_tasks WHERE task_id = ?", (task_id,))
        row = cur.fetchone()
        conn.close()
        if not row:
            return None
        return {"task_id": row[0], "filename": row[1], "upload_path": None, "status": row[2], "created_at": row[3]}
